import React, { useEffect, useState } from "react";
import DataTable from "react-data-table-component";
import "./Body.css";

const Body = () =>{

    const collumns = [
        {
            name: '#',
            selector: row => row.market_cap_rank
            ,sortable: true
        },
        {
            name: 'Name',
            selector: row => row.name
            ,sortable: true
        },
        {
            name: 'Price',
            selector: row => row.current_price
            ,sortable: true
        },
        {
            name: '24h%',
            selector: row => row.price_change_percentage_24h
            ,sortable: true
        },
        {
            name: 'Market Cap',
            selector: row => row.market_cap     
            ,sortable: true
        },
    ]

    

    const [fullData, setFullData] = useState([]);   

    const API = 'https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=100&page=1&sparkline=false&price_change_percentage=1d';
    
    const fetchuser = async (url) =>{
        try{
            const res = await fetch(url);
            const data = await res.json();
            
            if (data.length > 0){
                setFullData(data);
            }

        }catch (e) {
            console.error(e)
        }
    }

    useEffect(() => {
        fetchuser(API);
    },[])
 

    return(
        <div className="table-container">
            <DataTable
                minrows={5}
                columns={collumns}
                data={fullData}
                fixedHeader
                pagination
            ></DataTable>
        </div>
    )
}

export default Body;