import React from "react";
import "./Header.css";

const Header = ()=>{


    return(
        <div className="header-section">
            <div className="header">
                <div className="logo-section">
                    <img src="https://www.finmapp.com/wp-content/uploads/2021/09/abb.png" alt="logo"/>
                    <sup className="logo-theme">Your Financial Matchmaker</sup>
                </div>
                <div className="nav-section">
                    <a className="nav" href="index.html">Home</a>
                    <a className="nav" href="https://www.finmapp.com/about-us/" target="_blank">About</a>
                </div>
            </div>
        </div>
    )
}

export default Header;