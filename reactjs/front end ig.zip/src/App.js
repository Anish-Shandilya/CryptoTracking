import Header from './Components/Header/Header';
import Footer from './Components/Footer/Footer';
import Body from './Components/Body/Body';
import './App.css';

const App = () =>{
  return (
    <div >
      <Header/>
      <Body/>
      <Footer/>
    </div>
  );
}

export default App;
